<!DOCTYPE html>
<html>
  <head>
    <meta charset=utf-8>
    <title>mafo</title>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBvVNJMxhWDbOuRBI5LDRDEEgowSmEZr0o&libraries=drawing,geometry" async defer=defer></script>
    <link href=/static/css/app.b4ef642e71daee7b84cf703464831327.css rel=stylesheet>
  </head>
  <body>
    <div id=app></div>
    <script type=text/javascript src=/static/js/manifest.d0da714ca75d06392e14.js></script>
    <script type=text/javascript src=/static/js/vendor.57dc8c587f97015850db.js></script>
    <script type=text/javascript src=/static/js/app.094c12c93fffae35394b.js></script>
  </body>
</html>
