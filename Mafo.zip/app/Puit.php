<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Puit extends Model
{
    //
    protected $fillable = [
        'lat','lng', 'alt', 'idsite','code',
    ];
}
