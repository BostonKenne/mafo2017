<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;

use App\Echantillon;

use App\Http\Requests;

class EchantillonsController extends Controller
{
    public function _construct(){
        $this->middleware('auth')->except(['index', 'show']);
    }
	
    public function index(){
		return Response::json(Echantillon::all(), 200, [], JSON_NUMERIC_CHECK);
    }

    public function create(){

    }

    public function store(Request $data){
        return Response::json(Echantillon::create($data->all()), 200, [], JSON_NUMERIC_CHECK);
    }

    public function update($id, Request $request){

    }

    public function show($id){
        try {
            $echantillon = Echantillon::findOrFail($id);
            $echantillon->puit = Puit::all()->where('id','=',$echantillon->idpuit);
            return Response::json($type, 200, [], JSON_NUMERIC_CHECK);
        } catch (ModelNotFoundException $ex) {
            return Response::json(['error'=>'Cette echantillon n\'existe pas...'], 401, [], JSON_NUMERIC_CHECK);
        }
    }

    public function destroy($id){
        try {
            return Response::json(Echantillons::destroy($id), 200, [], JSON_NUMERIC_CHECK);
        } catch (ModelNotFoundException $ex) {
            return Response::json(['error'=>'Cette Echantillon n\'existe pas...'], 401, [], JSON_NUMERIC_CHECK);
        }
    }

    public function edit($id){

    }
}
