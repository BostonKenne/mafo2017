<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EchantillonParamController extends Controller
{
    //
}
