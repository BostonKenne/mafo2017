<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Echantillon extends Model
{
    //
    protected $fillable = [
        'code',
        'pfd_debut',
        'pfd_fin',
        'date',
        'autre_info',
        'couleur',
        'structure',
        'texture',
        'idpuit'
    ];
}
